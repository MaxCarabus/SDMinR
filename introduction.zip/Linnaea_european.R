setwd('k:/!_event_!/masterclass/sdm')
getwd()

# install.packages('rgdal')
# install.packages('raster')
# install.packages('maptools')
# install.packages('rgeos') 

library(rgdal)
library(raster)
library(maptools)
library(rgeos)

lb = read.csv('Linnaea_borealis_GBIF_Russia_2020-08-02.csv')

data("wrld_simpl")
plot(wrld_simpl, xlim = c(30,120), ylim = c(40,70), axes = T, col = 'darkseagreen1')
points(lb$lon, lb$lat, pch = 16, col = 'blue')

aoi = shapefile('european')
crs(aoi)
plot(aoi)
box()
points(lb$lon, lb$lat, pch = 16, col = 'blue')


coordinates(lb) = ~ lon + lat
crs(lb)
crs(lb) = crs(aoi)
lbe = intersect(lb,aoi)
points(lbe$lon, lbe$lat, pch = 16, col = 'red')

plot(aoi)
box()
points(lbe$lon, lbe$lat, pch = 16, col = 'red')
write.csv(lbe, file='Linnaea_european_selected.csv')