# https://github.com/MaxCarabus/SDMinR
library(raster)

# GADM: Global Administrative Areas https://gadm.org/
Austria0 = getData("GADM", country = 'AUT', level = 0)
Austria1 = getData("GADM", country = 'AUT', level = 1)
Austria2 = getData("GADM", country = 'AUT', level = 2)

plot(Austria2)

#save to shapefile
setwd('.......')

library('rgdal') # GDAL - Geospatial Data Abstraction Library
writeOGR(Austria0,'.',"Austria_boundary_0",driver = 'ESRI Shapefile')

#SRTM - Shuttle Radar Topography Mission (-56...+60), resolution ~ 90m
venue = getData('SRTM', lat = 56.8, lon = 60.6)
plot(venue) 
points(60.6,56.8)
writeRaster(venue, "venue.tif")

AustriaAlt = getData('alt', country = 'AUT')
plot(AustriaAlt)
plot(Austria1, add = T)

# list of countries
getData('ISO3')

#World Climate
tmin = getData('worldclim', var = 'tmin', res = 5)
class(tmin)
nlayers(tmin)
res(tmin)
extent(tmin)
plot(tmin[[c(2,7,9,11)]])

alt = getData('worldclim', var = 'alt', res = 5)
plot(alt)

# resolutions 10, 5, 2.5, 0.5
prec = getData('worldclim', var = 'prec', res = 5)
plot(prec)
plot(prec[[4]])

bio = getData('worldclim', var = 'bio', res = 5)

# precipitation of Driest Month

bio14 = bio[[14]]
plot(bio14)

# CMIP5 - Coupled Model Intercomparison Project phase 5
# https://pcmdi.llnl.gov/mips/cmip5/
rcp = getData('CMIP5', var = 'bio', model = 'HE', rcp = 26, res = 10, year = 70)
plot(rcp[[19]])


# PREDICTORS
path = '......./predictors'
layers = list.files(path)

setwd(path)
soil20_1 = raster(layers[6])
bio1 = raster(layers[1])
plot(bio1)

# resample
res(soil20_1)
res(bio1)

bio1r = resample(bio1, soil20_1)
res(bio1r)

plot(bio1)
plot(bio1r)

crs(bio1)
crs(soil20_1)
# projectRaster(layer1, layer2)

layerNames = c('bio01','bio05','bio06','bio12','elev','t_soil20_1','t_soil20_5','t_soil_20_6','t_soil20_9')

bio5 = raster(layers[2]) # Max Temperature of Warmest Month
bio6 = raster(layers[3]) # Min Temperature of Coldest Month
bio12 = raster(layers[4]) # Annual Precipitation
elevation = raster(layers[5])
soil20_5 = raster(layers[7])
soil20_6 = raster(layers[8])
soil20_9 = raster(layers[9])
plot(soil20_6)

predictors = stack(bio1,bio5,bio6,bio12,elevation,soil20_1,soil20_5,soil20_6,soil20_9)

bio1c = crop(bio1,soil20_1)
extent(bio1r)
extent(soil20_1)
bio5r = resample(bio5,soil20_1)
res(bio5r)
extent(bio5r)
extent(soil20_1)

bio6r = resample(bio6,soil20_1)
bio12r = resample(bio12,soil20_1)
elevationr = resample(elevation,soil20_1)

predictors = stack(bio1r,bio5r,bio6r,bio12r,elevationr,soil20_1,soil20_5,soil20_6,soil20_9)
nlayers(predictors)
class(predictors)

names(predictors) = layerNames
plot(predictors)


# occurrence points
setwd('.......')
ac_occurs = read.csv('ac_gbif.csv')
aoi = shapefile('Russia_european')
plot(aoi)
points(ac_occurs$decimalLongitude, ac_occurs$decimalLatitude, pch = 20, col = 'red', cex = 0.7)

class(aoi)
class(ac_occurs) 

coordinates(ac_occurs) = ~ decimalLongitude + decimalLatitude

class(ac_occurs)

ac_occurs_aoi = intersect(ac_occurs, aoi)

plot(aoi)
plot(ac_occurs_aoi, add = T, pch = 20, col = 'red', cex = 0.7)

# get environmental data according occurences
envValues = extract(predictors, ac_occurs_aoi)
inputData = data.frame(ac_occurs_aoi,envValues)
colnames(inputData)
inputData$X = NULL
colnames(inputData)
head(inputData)