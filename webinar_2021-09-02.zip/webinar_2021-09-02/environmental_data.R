setwd('/media/dryomys/Transcend/study/SDM/2021-09_Ekaterinburg/webinar2/')
getwd()

library('raster')
library('rgeos')
install.packages('fields')
library('fields')

# load area of interests (AOI)
aoi = shapefile('Russia_European_albers')
crs(aoi)
plot(aoi)

# reproject into WGS84 - decimal degree
aoidd = spTransform(aoi, CRS("+proj=longlat +datum=WGS84"))
plot(aoidd)

# WORLDCLIM

# color palette for temperature gradients - winter and summer
colfuncw <- colorRampPalette(c('blue','cyan','aliceblue'))
colfuncws <- colorRampPalette(c('aliceblue','cyan','blue'))
colfuncs <- colorRampPalette(c('seagreen','green','yellow','coral'))
colfunc  <- colorRampPalette(c('blue','cyan','green','yellow'))
colfuncp <- colorRampPalette(c("red3","orange","yellow","green", "lightskyblue","steelblue3", "royalblue3"))

# annual mean temperature
bio1 = raster('wc2.1_10m_bio_01.tif')
bio1c = crop(bio1, aoidd) 
bio1m = mask(bio1c, aoidd)
plot(bio1m, main = 'annual mean temperature', col = colfunc(32))
plot(aoidd, add = T)


# Temperature Seasonality
bio4 = raster('wc2.1_10m_bio_04.tif')
bio4c = crop(bio4, aoidd)
bio4m = mask(bio4c, aoidd)
plot(bio4m, main = 'Temperature Seasonality (standard deviation x 100)', col = colfuncs(32))
plot(aoidd, add = T)


# Annual Precipitation
bio12 = raster('wc2.1_10m_bio_12.tif')
bio12c = crop(bio12, aoidd)
bio12m = mask(bio12c, aoidd)
plot(bio12m, main = 'Annual Precipitation', col = colfuncp(32))
plot(aoidd, add = T)


# elevation
elev = raster('wc2.1_10m_elev.tif')
elevc = crop(elev, aoidd)
elevm = mask(elevc, aoidd)
plot(elevm, main = 'elevation')
plot(aoidd, add = T)


# SNOW COVER
snowCover = read.csv('snow_cover_monthly.csv')
coordinates(snowCover) = ~ longitude + latitude
crs(snowCover) = CRS("+proj=longlat +datum=WGS84")
snowCoverS = intersect(snowCover, aoidd)
plot(snowCoverS)
plot(aoidd, add = T)
snowCoverS1 = snowCoverS[snowCoverS$month_ == 1,]
blankR = raster(extent(aoidd), resolution = 0.05) # resolution in dd is about 5 km
snowCoverR1 = rasterize(snowCoverS1, blankR, 'average_depth')
xy <- data.frame(xyFromCell(snowCoverR1, 1:ncell(snowCoverR1)))
v <- getValues(snowCoverR1)
tps <- Tps(xy, v)
snowCover1 = interpolate(snowCoverR1, tps)
snowCover1m = mask(snowCover1, aoidd)
plot(snowCover1m, col = colfuncws(16), main = 'mean snow cover in January')
plot(aoidd, add = T)


# SOIL TEMPERATURE
soil20sep = read.csv('soil_month_avg_20_Sep_upd.csv')
coordinates(soil20sep) = ~ longitude + latitude
crs(soil20sep) = CRS("+proj=longlat +datum=WGS84")
soil20sepS = intersect(soil20sep, aoidd)
plot(soil20sepS, pch = 17, col = 'blue') 
plot(aoidd, add = T)
blankR = raster(extent(aoidd), resolution = 0.05) # resolution in dd is about 5 km
soil20sepR = rasterize(soil20sepS, blankR, 'average_t')
xy <- data.frame(xyFromCell(soil20sepR, 1:ncell(soil20sepR)))
v <- getValues(soil20sepR)
tps <- Tps(xy, v) # Thin Plate Spline interpolation
soil20_9 = interpolate(soil20sepR, tps)
soil20_9m = mask(soil20_9, aoidd)
plot(soil20_9m, col = colfuncs(16), main = 'mean long-term t of soil for September, 20 cm depth')
plot(aoidd, add = T)
plot(soil20sepS, pch = 17, cex = 0.75, col = 'blue', add = T)