setwd('/media/dryomys/Transcend/study/SDM/2021-09_Ekaterinburg/Ac_project')

install.packages('raster')
install.packages('rgeos')
install.packages('dismo')

library('raster')
library('dismo')
library('rgeos')
library('fields')
library('rgdal')

# load area of interests (AOI)
aoi = shapefile('Russia_European_albers')
crs(aoi)
plot(aoi)
  
# reproject into WGS84 - decimal degree
aoidd = spTransform(aoi, CRS("+proj=longlat +datum=WGS84"))
plot(aoidd)
writeOGR(aoidd, '.','Russia_European_dd', driver = 'ESRI Shapefile')

# Aporrectodea caliginosa occurrences - literature
# https://www.gbif.org/dataset/e52aacbf-c701-462b-b68f-346502fbc270
acl = read.csv('0251968-200613084148143.csv', sep ='\t')
nrow(acl)

# Aporrectodea caliginosa occurrences - GBIF
acl = read.csv('ac_gbif.csv')
nrow(acl)

# convert into spatial object
class(acl)
coordinates(acl) = ~ decimalLongitude + decimalLatitude
class(acl)
length(acl)

# set CRS
crs(acl) # CRS must be specified
crs(acl) = CRS("+proj=longlat +datum=WGS84") # define CRS
crs(acl)

# select EW occurrences inside AOI (in decimal degree)
acls = intersect(acl, aoidd)
length(acls)
plot(acls, add = T, pch = 20, col = 'red', cex = 0.8)


# reproject into Albers West
aclpr = spTransform(acls, crs(aoi))
plot(aoi)
plot(aclpr, add = T, pch = 20, col = 'red', cex = 0.8)
  
# WORLDCLIM

# color palette for temperature gradients - winter and summer
colfuncw <- colorRampPalette(c('blue','cyan','aliceblue'))
colfuncws <- colorRampPalette(c('aliceblue','cyan','blue'))
colfuncs <- colorRampPalette(c('seagreen','green','yellow','coral'))
colfunc  <- colorRampPalette(c('blue','cyan','green','yellow'))
colfuncp <- colorRampPalette(c("red3","orange","yellow","green", "lightskyblue","steelblue3", "royalblue3"))
colfunelev <- colorRampPalette(c('chartreuse4','chartreuse3','darkolivegreen1','gold','gold2','orange','orange3','orange4'))
  
# annual mean temperature
bio1 = raster('env_data/worldclim/wc2.1_10m_bio_01.tif')
plot(bio1, main = 'annual mean temperature', col = colfunc(32))
bio1c = crop(bio1, aoidd)
plot(bio1c, main = 'annual mean temperature', col = colfunc(32))
bio1m = mask(bio1c, aoidd)
plot(bio1m, main = 'annual mean temperature', col = colfunc(32))
plot(aoidd, add = T)

# Temperature Seasonality
bio4 = raster('env_data/worldclim/wc2.1_10m_bio_04.tif')
bio4c = crop(bio4, aoidd)
bio4m = mask(bio4c, aoidd)
plot(bio4m, main = 'Temperature Seasonality (standard deviation х100)', col = colfuncs(32))
plot(aoidd, add = T)

# Max Temperature of Warmest Month
bio5 = raster('env_data/worldclim/wc2.1_10m_bio_05.tif')
bio5c = crop(bio5, aoidd)
bio5m = mask(bio5c, aoidd)
plot(bio5m, main = 'Max Temperature of Warmest Month', col = colfuncs(32))
plot(aoidd, add = T)

# Min Temperature of Coldest Month
bio6 = raster('env_data/worldclim/wc2.1_10m_bio_06.tif')
bio6c = crop(bio6, aoidd)
bio6m = mask(bio6c, aoidd)
plot(bio6m, main = 'Min Temperature of Coldest Month', col = colfuncw(32))
plot(aoidd, add = T)

# Annual Precipitation
bio12 = raster('env_data/worldclim/wc2.1_10m_bio_12.tif')
bio12c = crop(bio12, aoidd)
bio12m = mask(bio12c, aoidd)
plot(bio12m, main = 'Annual Precipitation', col = colfuncp(32))
plot(aoidd, add = T)

# Precipitation of Driest Quarter
bio17 = raster('env_data/worldclim/wc2.1_10m_bio_17.tif')
bio17c = crop(bio17, aoidd)
bio17m = mask(bio17c, aoidd)
plot(bio17m, main = 'Precipitation of Driest Quarter', col = colfuncp(32))
plot(aoidd, add = T)

# Precipitation of Warmest Quarter
bio18 = raster('env_data/worldclim/wc2.1_10m_bio_18.tif')
bio18c = crop(bio18, aoidd)
bio18m = mask(bio18c, aoidd)
plot(bio18m, main = 'Precipitation of Warmesr Quarter', col = colfuncp(32))
plot(aoidd, add = T)

# elevation
elev = raster('env_data/worldclim/wc2.1_10m_elev.tif')
elevc = crop(elev, aoidd)
elevm = mask(elevc, aoidd)
plot(elevm, main = 'elevation', col = colfunelev(32))
plot(aoidd, add = T)

# save rasters
writeRaster(bio1m, filename = 'predictors/bio01_aoi.tiff', format = 'GTiff')
writeRaster(bio5m, filename = 'predictors/bio05_aoi.tiff', format = 'GTiff')
writeRaster(bio6m, filename = 'predictors/bio06_aoi.tiff', format = 'GTiff')
writeRaster(bio12m, filename = 'predictors/bio12_aoi.tiff', format = 'GTiff')
writeRaster(elevm, filename = 'predictors/evelm_aoi.tiff', format = 'GTiff')


# SNOW COVER
snowCover = read.csv('env_data/snow_cover_monthly.csv')
coordinates(snowCover) = ~ longitude + latitude
crs(snowCover) = CRS("+proj=longlat +datum=WGS84")
snowCoverS = intersect(snowCover, aoidd)
snowCoverS1 = snowCoverS[snowCoverS$month_ == 1,]
blankR = raster(extent(aoidd), resolution = 0.05) # resolution in dd is about 5 km
snowCoverR1 = rasterize(snowCoverS1, blankR, 'average_depth')
xy <- data.frame(xyFromCell(snowCoverR1, 1:ncell(snowCoverR1)))
v <- getValues(snowCoverR1)
tps <- Tps(xy, v)
snowCover1 = interpolate(snowCoverR1, tps)
snowCover1m = mask(snowCover1, aoidd)
plot(snowCover1m, col = colfuncws(16), main = 'mean snow cover in January')
plot(aoidd, add = T)

# SOIL TEMPERATURE
# create soil temperature raster
soil20jan = read.csv('env_data/soil_month_avg_20_Jan_upd.csv')
soil20may = read.csv('env_data/soil_month_avg_20_May_upd.csv')
soil20jun = read.csv('env_data/soil_month_avg_20_Jun_upd.csv')
soil20sep = read.csv('env_data/soil_month_avg_20_Sep_upd.csv')

coordinates(soil20jan) = ~ longitude + latitude
coordinates(soil20may) = ~ longitude + latitude
coordinates(soil20jun) = ~ longitude + latitude
coordinates(soil20sep) = ~ longitude + latitude

# assign WGS84
crs(soil20jan) = CRS("+proj=longlat +datum=WGS84")
crs(soil20may) = CRS("+proj=longlat +datum=WGS84")
crs(soil20jun) = CRS("+proj=longlat +datum=WGS84")
crs(soil20sep) = CRS("+proj=longlat +datum=WGS84")

# select weather stations inside AOI
soil20janS = intersect(soil20jan, aoidd)
soil20mayS = intersect(soil20may, aoidd)
soil20junS = intersect(soil20jun, aoidd)
soil20sepS = intersect(soil20sep, aoidd)

plot(soil20jan, pch = 17, col = 'blue', cex = 0.8)
plot(soil20janS, pch = 17, col = 'blue', cex = 0.8)
plot(aoidd, add = T)

# empty raster as base for temperature
blankR = raster(extent(aoidd), resolution = 0.05) # resolution in dd is about 5 km

soil20janR = rasterize(soil20janS, blankR, 'average_t')
soil20mayR = rasterize(soil20mayS, blankR, 'average_t')
soil20junR = rasterize(soil20junS, blankR, 'average_t')
soil20sepR = rasterize(soil20sepS, blankR, 'average_t')


# interpolation
xy <- data.frame(xyFromCell(soil20janR, 1:ncell(soil20janR)))
v <- getValues(soil20janR)
tps <- Tps(xy, v)
soil20_1 = interpolate(soil20janR, tps)
soil20_1m = mask(soil20_1, aoidd)

xy <- data.frame(xyFromCell(soil20mayR, 1:ncell(soil20mayR)))
v <- getValues(soil20mayR)
tps <- Tps(xy, v)
soil20_5 = interpolate(soil20mayR, tps)
soil20_5m = mask(soil20_5, aoidd)

xy <- data.frame(xyFromCell(soil20junR, 1:ncell(soil20junR)))
v <- getValues(soil20junR)
tps <- Tps(xy, v)
soil20_6 = interpolate(soil20junR, tps)
soil20_6m = mask(soil20_6, aoidd)

xy <- data.frame(xyFromCell(soil20sepR, 1:ncell(soil20sepR)))
v <- getValues(soil20sepR)
tps <- Tps(xy, v)
soil20_9 = interpolate(soil20sepR, tps)
soil20_9m = mask(soil20_9, aoidd)

par(mfrow = c(2,2))
plot(soil20_1m, col = colfuncw(16), main = 'mean long-term t of January')
plot(aoidd, add = T)
plot(soil20janS, pch = 17, cex = 0.75, col = 'blue', add = T)
plot(soil20_5m, col = colfuncs(16), main = 'mean long-term t of May')
plot(aoidd, add = T)
plot(soil20mayS, pch = 17, cex = 0.75, col = 'blue', add = T)
plot(soil20_6m, col = colfuncs(16), main = 'mean long-term t of June')
plot(aoidd, add = T)
plot(soil20junS, pch = 17, cex = 0.75, col = 'blue', add = T)
plot(soil20_9m, col = colfuncs(16), main = 'mean long-term t of September')
plot(aoidd, add = T)
plot(soil20sepS, pch = 17, cex = 0.75, col = 'blue', add = T)
plot(acls, pch = 20, cex = 0.75, col = 'red', add = T)


# define CRS 
crs(soil20_1m) = '+proj=longlat +datum=WGS84'
crs(soil20_5m) = '+proj=longlat +datum=WGS84'
crs(soil20_6m) = '+proj=longlat +datum=WGS84'
crs(soil20_9m) = '+proj=longlat +datum=WGS84'

# write generated rasteds
writeRaster(soil20_1m, filename = 'predictors/soil20_1.tiff', format = 'GTiff')
writeRaster(soil20_5m, filename = 'predictors/soil20_5.tiff', format = 'GTiff')
writeRaster(soil20_6m, filename = 'predictors/soil20_6.tiff', format = 'GTiff')
writeRaster(soil20_9m, filename = 'predictors/soil20_9.tiff', format = 'GTiff')

# pseudo-absence points
acbg = randomPoints(soil20_5m, 200)
acbg = as.data.frame(acbg)
colnames(acbg)
coordinates(acbg) = ~ x + y
plot(soil20_1m, col = colfuncw(32), main = 'Presence and pseudo-absence points')
plot(acbg, pch = 1, cex = 0.75, col = 'blue', add = T)
plot(acls, pch = 20, cex = 0.75, col = 'red', add = T)
plot(aoidd, add = T)

plot(soil20_5m, col = colfuncs(32), main = 'mean long-term t of May')
plot(acbg, pch = 1, cex = 0.75, col = 'blue', add = T)
plot(acls, pch = 17, cex = 0.75, col = 'red', add = T)
plot(aoidd, add = T)


# PREDICTORS
base = getwd()
path = file.path(paste(base,'/predictors'),sep='')
layers = list.files(path)


# resample
res(soil20_1m)
res(bio1m)

bio1r = resample(bio1m, soil20_1m)
res(bio1r)
bio4r = resample(bio4m, soil20_1m)
bio5r = resample(bio5m, soil20_1m)
bio6r = resample(bio6m, soil20_1m)
bio12r = resample(bio12m, soil20_1m)
bio17r = resample(bio17m, soil20_1m)
bio18r = resample(bio18m, soil20_1m)
elevr = resample(elevm, soil20_1m)
extent(elevr)
extent(soil20_1m)

lnames = c('bio01','bio04','bio05','bio06','bio12','bio17','bio18','elev','t20_1','t20_5','t20_6','t20_9')
predictors = stack(bio1r,bio4r,bio5r,bio6r,bio12r,bio17r,bio18r,elevr,soil20_1m,soil20_5m,soil20_6m,soil20_9m)
names(predictors) = lnames
plot(predictors)

# points of presence and absence
prsval = extract(predictors, acls)
absval = extract(predictors, acbg)
presence = c(rep(1, nrow(prsval)), rep(0, nrow(absval)))
sdmdata = data.frame(presence, rbind(prsval, absval))
colnames(sdmdata)

write.csv(sdmdata, 'ac_input.csv')
sdmdata = read.csv('ac_input.csv')

# modelling 
m1 = glm(presence ~ bio01 + bio04 + bio05 + bio12 + bio17 + bio18, data = sdmdata, family = 'binomial')
summary(m1)

m2 = glm(presence ~ ., data = sdmdata, family = 'binomial')
summary(m2)

m3 = glm(presence ~ bio12 + elev + t20_1 + t20_6, data = sdmdata, family = 'binomial')
summary(m3)

m4 = glm(presence ~ bio04 + bio17 + bio18 + t20_1 + t20_6, data = sdmdata, family = 'binomial')
summary(m4)


install.packages('PerformanceAnalytics')
library(PerformanceAnalytics)
chart.Correlation(sdmdata[,3:14])

# logit
pt = predict(predictors, m1, type = 'response')
plot(pt)

# probability
ptp = predict(predictors, m4, type = 'response')
plot(ptp)

writeRaster(pt, filename = 'prediction_m1_binomial.tiff', format = 'GTiff')


#resudials
par(mfrow = c(2,2))
plot(m1$residuals ~ sdmdata$bio01)
plot(m1$residuals ~ sdmdata$bio05)
plot(m1$residuals ~ sdmdata$bio12)

ev = evaluate(sdmdata[sdmdata$presence == 1,], sdmdata[sdmdata$presence == 0,], m1) 
plot(ev, 'ROC')